Piyaso uygulamasının gerçek ekran kaydını bu klasöre app_recording.mp4 adıyla ekleyin.
