Bu klasöre kendi/lisanslı videolarınızı atın. Örnek: araba_01.mp4, karaoke_01.mp4, sarki_01.mp4.
3 video yayınlanan günler için en az 3 farklı kaynak video gerekir.
Kaynak videolardaki gömülü yazıların üstüne bir Piyaso başlığı koymak için clip_settings.json içinde 'headline_box' koordinatlarını ayarlayın.
Başka yerde yazı varsa 'cover_rectangles' listesine opak kapatma kutusu ekleyin.
