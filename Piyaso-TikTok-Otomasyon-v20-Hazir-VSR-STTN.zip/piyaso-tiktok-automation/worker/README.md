# Piyaso final ad video Worker

- Bound R2 bucket: **piyaso-tiktok-assets** (only this; Davethemen not bound).
- Public URL: `GET|HEAD /piyaso/YYYY-MM-DD/SLOT/video.mp4`.
- Internally reads **`published/piyaso/YYYY-MM-DD/SLOT/video.mp4`** from private R2.
- All other URLs and raw footage / app recordings / state records are denied.
- No API keys are coded here. Keep R2 public access disabled.

Verify locally: `node worker/test.mjs`

Deploy using Cloudflare Workers dashboard (paste `src/index.js`, add R2 binding `MEDIA`), or with `npx wrangler deploy` after Cloudflare authentication. Get workers.dev URL and set `R2_PUBLIC_BASE_URL` GitHub variable.

**No Worker has been deployed merely by writing this repository.**
